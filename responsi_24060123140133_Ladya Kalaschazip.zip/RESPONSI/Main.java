import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        // Membuat objek Fakultas
        Fakultas FSM = new Fakultas("Sains dan Matematika", 5000000, 7000000);
        Fakultas FEB = new Fakultas("Ekonomi", 4500000, 6500000);

        // Membuat beberapa Mahasiswa
        Mahasiswa mhs1 = new Mahasiswa("Ladya Kalascha", "Ladya@student.ac.id", "24001", 1, FSM);
        Mahasiswa mhs2 = new Mahasiswa("Orlando Kalascha", "Orlando@student.ac.id", "24002", 3, FEB);

        // Membuat beberapa Dosen (tanggal masuk digunakan untuk hitung masa kerja)
        Dosen dosen1 = new Dosen("Dr. Andi", "andi@univ.ac.id", "1978001", LocalDate.of(2010, 5, 15), "Kepala Departemen", FSM);
        Dosen dosen2 = new Dosen("Prof. Rina", "rina@univ.ac.id", "1967002", LocalDate.of(2005, 8, 10), "Wakil Kepala Departemen", FEB);

        // Membuat beberapa Tendik (tanggal masuk digunakan untuk hitung masa kerja)
        Tendik tendik1 = new Tendik("Pak Budi", "budi@univ.ac.id", "1985001", LocalDate.of(2008, 2, 20));
        Tendik tendik2 = new Tendik("Bu Sri", "sri@univ.ac.id", "1990002", LocalDate.of(2015, 6, 5));

        // Menampilkan informasi mahasiswa
        System.out.println("\n╔════════════════════════════╗");
        System.out.println("║       DATA MAHASISWA       ║");
        System.out.println("╚════════════════════════════╝\n");
        System.out.println(mhs1);
        System.out.println("Biaya UKT: Rp" + mhs1.hitungUKT());
        System.out.println("\n------------------------------\n");
        System.out.println(mhs2);
        System.out.println("Biaya UKT: Rp" + mhs2.hitungUKT());

        // Menampilkan informasi dosen
        System.out.println("\n╔════════════════════════════╗");
        System.out.println("║        DATA DOSEN          ║");
        System.out.println("╚════════════════════════════╝\n");
        System.out.println(dosen1);
        System.out.println("Masa Kerja: " + dosen1.getMasaKerja() + " tahun");
        System.out.println("Gaji: Rp" + dosen1.hitungGaji());
        System.out.println("\n------------------------------\n");
        System.out.println(dosen2);
        System.out.println("Masa Kerja: " + dosen2.getMasaKerja() + " tahun");
        System.out.println("Gaji: Rp" + dosen2.hitungGaji());

        // Menampilkan informasi tendik
        System.out.println("\n╔════════════════════════════╗");
        System.out.println("║        DATA TENDIK         ║");
        System.out.println("╚════════════════════════════╝\n");
        System.out.println(tendik1);
        System.out.println("Gaji: Rp" + tendik1.hitungGaji());
        System.out.println("\n------------------------------\n");
        System.out.println(tendik2);
        System.out.println("Gaji: Rp" + tendik2.hitungGaji());

        // Menampilkan jumlah instance dari setiap kategori
        System.out.println("\n╔════════════════════════════╗");
        System.out.println("║    COUNTER INSTANSI        ║");
        System.out.println("╚════════════════════════════╝\n");
        System.out.println("Total Mahasiswa: " + Mahasiswa.getJumlahMahasiswa());
        System.out.println("Total Dosen: " + Dosen.getJumlahDosen());
        System.out.println("Total Tendik: " + Tendik.getJumlahTendik());
    }
}