import java.time.LocalDate;
import java.time.Period;

public abstract class Karyawan extends CivitasAkademika {
    protected String NIP;
    protected LocalDate tanggalMasuk;

    // Constructor
    public Karyawan(String nama, String email, String NIP, LocalDate tanggalMasuk) {
        super(nama, email);
        this.NIP = NIP;
        this.tanggalMasuk = tanggalMasuk;
    }

    // Getter dan Setter
    public String getNIP() {
        return NIP;
    }

    public void setNIP(String NIP) {
        this.NIP = NIP;
    }

    public LocalDate getTanggalMasuk() {
        return tanggalMasuk;
    }

    public void setTanggalMasuk(LocalDate tanggalMasuk) {
        this.tanggalMasuk = tanggalMasuk;
    }

    // Method untuk menghitung masa kerja (dalam tahun)
    public int getMasaKerja() {
        return hitungMasaKerja();
    }

    private int hitungMasaKerja() {
        return Period.between(tanggalMasuk, LocalDate.now()).getYears();
    }

    // Abstract method untuk menghitung gaji
    public abstract double hitungGaji();
}