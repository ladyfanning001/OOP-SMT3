import java.time.LocalDate;
import java.time.Period;

public class Tendik extends Karyawan {
    private static final double GAJI_POKOK = 4000000;
    private static int jumlahTendik = 0; // Counter

    // Konstruktor
    public Tendik(String nama, String email, String NIP, LocalDate tanggalMasuk) {
        super(nama, email, NIP, tanggalMasuk);
        jumlahTendik++;
    }

    // Getter jumlah Tendik
    public static int getJumlahTendik() {
        return jumlahTendik;
    }

    // Method hitung gaji berdasarkan masa kerja
    @Override
    public double hitungGaji() {
        return GAJI_POKOK * (1 + (getMasaKerja() * 0.01));
    }

    // Method menampilkan informasi
    @Override
    public void tampilkanInfo() {
        System.out.println("Nama: " + nama);
        System.out.println("Email: " + email);
        System.out.println("NIP: " + NIP);
        System.out.println("Tanggal Masuk: " + tanggalMasuk);
        System.out.println("Masa Kerja: " + getMasaKerja() + " tahun");
        System.out.println("Gaji: Rp" + hitungGaji());
    }

    @Override
    public String toString() {
        return "Nama        : " + getNama() + "\n"
             + "Email       : " + getEmail() + "\n"
             + "NIP         : " + NIP + "\n"
             + "Tanggal Masuk : " + tanggalMasuk + "\n"
             + "Masa Kerja  : " + getMasaKerja() + " tahun";
    }
}