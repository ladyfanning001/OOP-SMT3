import java.time.LocalDate;

public class Dosen extends Karyawan {
    private String jabatan;
    private Fakultas fakultas; // Fakultas tempat dosen bekerja

    private static int jumlahDosen = 0; 

    public Dosen(String nama, String email, String NIP, LocalDate tanggalMasuk, String jabatan, Fakultas fakultas) {
        super(nama, email, NIP, tanggalMasuk);
  
        this.jabatan = jabatan;
        this.fakultas = fakultas;
        jumlahDosen++; 
    }

    // Getter dan Setter
    public String getJabatan() {
        return jabatan;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }

    public Fakultas getFakultas() {
        return fakultas;
    }

    public void setFakultas(Fakultas fakultas) {
        this.fakultas = fakultas;
    }

    public static int getJumlahDosen() {
        return jumlahDosen;
    }

    // Hitung gaji (gaji pokok fakultas + 1% per tahun masa kerja)
    @Override
    public double hitungGaji() {
        double gajiPokok = fakultas.getGajiPokok();
        return gajiPokok + (getMasaKerja() * 0.01 * gajiPokok);
    }

    // Implementasi method abstrak
    @Override
    public void tampilkanInfo() {
        System.out.println("Dosen: " + getNama());
        System.out.println("Email: " + getEmail());
        System.out.println("NIP: " + getNIP());
        System.out.println("Jabatan: " + jabatan);
        System.out.println("Fakultas: " + fakultas.getNama());
        System.out.println("Masa Kerja: " + getMasaKerja() + " tahun");
        System.out.println("Gaji: Rp" + hitungGaji());
    }

    @Override
    public String toString() {
        return "Nama    : " + getNama() + "\n"
             + "Email   : " + getEmail() + "\n"
             + "NIP     : " + getNIP() + "\n"
             + "Jabatan : " + jabatan + "\n"
             + "Fakultas: " + fakultas.getNama();
    }
}